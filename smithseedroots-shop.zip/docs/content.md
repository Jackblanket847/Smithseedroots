# Content Notes
- Brand: **Smith Seed Roots**
- Voice: warm, practical, community-centered
- Tagline: *Rooted in quality. Growing community.*
- Audience: home gardeners, makers, local community
- TODO: add product photos, about page story, FAQs
